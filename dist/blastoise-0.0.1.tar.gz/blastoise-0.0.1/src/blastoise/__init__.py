"""__int__"""

MAX_FILES_SIZE = 80

__all__ = [
    "MAX_FILES_SIZE"
]
