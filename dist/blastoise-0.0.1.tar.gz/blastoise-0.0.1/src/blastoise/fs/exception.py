"""Exception throws in fs operation."""


class FileInfoNotReasonable(Exception):
    """File info, hierarchy and directory not suitable."""
