"""__init__"""
from .path import dir_to_name


__all__ = [
    "dir_to_name"
]
