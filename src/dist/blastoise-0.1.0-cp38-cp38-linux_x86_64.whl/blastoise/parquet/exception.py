"""Custom exception for parquet"""


class RepoDirectoryCantLoadAloneEception(Exception):
    """Directory in REPO hierarchy cant be loaded alone."""
